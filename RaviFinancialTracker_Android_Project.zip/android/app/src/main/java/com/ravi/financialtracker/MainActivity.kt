package com.ravi.financialtracker

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.ravi.financialtracker.ui.screens.*
import com.ravi.financialtracker.ui.theme.RaviFinanceTheme

enum class Screen(val titleEn: String, val titleHi: String, val icon: ImageVector) {
    HOME("Home", "होम", Icons.Default.Home),
    TRANSACTIONS("Transactions", "लेन-देन", Icons.Default.ReceiptLong),
    REPORTS("Reports", "रिपोर्ट्स", Icons.Default.BarChart),
    ACCOUNTS("Accounts", "खाते व कार्ड", Icons.Default.AccountBalance),
    SETTINGS("Settings", "सेटिंग्स", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Handle incoming Android Sharesheet intent (e.g. sharing bank SMS or statement)
        val sharedText = if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            intent.getStringExtra(Intent.EXTRA_TEXT)
        } else null

        setContent {
            var currentScreen by remember { mutableStateOf(Screen.HOME) }
            var isHindi by remember { mutableStateOf(true) } // Default Hindi as requested

            RaviFinanceTheme {
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            Screen.values().forEach { screen ->
                                NavigationBarItem(
                                    selected = currentScreen == screen,
                                    onClick = { currentScreen = screen },
                                    icon = { Icon(screen.icon, contentDescription = screen.titleEn) },
                                    label = { Text(if (isHindi) screen.titleHi else screen.titleEn) }
                                )
                            }
                        }
                    }
                ) { paddingValues ->
                    Box(modifier = Modifier.padding(paddingValues)) {
                        when (currentScreen) {
                            Screen.HOME -> HomeScreen(isHindi = isHindi, onNavigateToTransactions = { currentScreen = Screen.TRANSACTIONS })
                            Screen.TRANSACTIONS -> TransactionsScreen(isHindi = isHindi, sharedText = sharedText)
                            Screen.REPORTS -> ReportsScreen(isHindi = isHindi)
                            Screen.ACCOUNTS -> AccountsScreen(isHindi = isHindi)
                            Screen.SETTINGS -> SettingsScreen(
                                isHindi = isHindi,
                                onLanguageChange = { isHindi = it }
                            )
                        }
                    }
                }
            }
        }
    }
}
