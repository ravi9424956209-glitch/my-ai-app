package com.ravi.financialtracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravi.financialtracker.ui.theme.*

@Composable
fun TransactionsScreen(
    isHindi: Boolean,
    sharedText: String? = null
) {
    var filterStatus by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(sharedText != null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
    ) {
        // Title & Search
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isHindi) "लेन-देन प्रबंधन (Transactions)" else "Transactions Management",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
            IconButton(onClick = { showImportDialog = true }) {
                Icon(Icons.Default.UploadFile, contentDescription = "Import SMS / Statement", tint = EmeraldAccent)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(if (isHindi) "व्यापारी, बैंक या यूटीआर खोजें..." else "Search merchant, bank or UTR...") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Filter chips: All, Pending, Approved, Rejected
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("All", "Pending", "Approved", "Rejected").forEach { status ->
                FilterChip(
                    selected = filterStatus == status,
                    onClick = { filterStatus = status },
                    label = {
                        Text(
                            when(status) {
                                "Pending" -> if (isHindi) "लंबित (Pending)" else "Pending"
                                "Approved" -> if (isHindi) "स्वीकृत (Approved)" else "Approved"
                                "Rejected" -> if (isHindi) "अस्वीकृत (Rejected)" else "Rejected"
                                else -> if (isHindi) "सभी (All)" else "All"
                            }
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Transactions list
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Item 1: Pending POS
            item {
                TransactionCard(
                    merchant = "Urban Ladder Furniture",
                    bank = "HDFC Bank ••3819",
                    date = "27 Oct 2026, 19:45",
                    amount = "₹2,450",
                    isCredit = false,
                    status = "pending",
                    category = "Shopping",
                    notes = "AI Detected: Card Swipe alert",
                    isHindi = isHindi
                )
            }

            // Item 2: Pending UPI
            item {
                TransactionCard(
                    merchant = "Starbucks Coffee Bangalore",
                    bank = "ICICI Bank ••7103",
                    date = "28 Oct 2026, 08:12",
                    amount = "₹620",
                    isCredit = false,
                    status = "pending",
                    category = "Food & Dining",
                    notes = "AI Detected: UPI Merchant QR payment",
                    isHindi = isHindi
                )
            }

            // Item 3: Approved Salary
            item {
                TransactionCard(
                    merchant = "Acme Technologies Pvt Ltd",
                    bank = "HDFC Bank ••4892",
                    date = "01 Oct 2026, 09:15",
                    amount = "₹1,85,000",
                    isCredit = true,
                    status = "approved",
                    category = "Salary",
                    notes = "Ref: CMS1829482910",
                    isHindi = isHindi
                )
            }

            // Item 4: Approved SBI EMI
            item {
                TransactionCard(
                    merchant = "SBI Home Loan EMI AutoDebit",
                    bank = "SBI ••9921",
                    date = "05 Oct 2026, 06:00",
                    amount = "₹38,500",
                    isCredit = false,
                    status = "approved",
                    category = "Loan & EMI",
                    notes = "Auto-debited via NACH",
                    isHindi = isHindi
                )
            }
        }
    }
}

@Composable
fun TransactionCard(
    merchant: String,
    bank: String,
    date: String,
    amount: String,
    isCredit: Boolean,
    status: String,
    category: String,
    notes: String,
    isHindi: Boolean
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = merchant, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = NavyPrimary)
                    Text(text = "$bank • $date", fontSize = 11.sp, color = SlateTextSecondary)
                }
                Text(
                    text = "${if (isCredit) "+" else "-"}$amount",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = if (isCredit) EmeraldAccent else RoseExpense
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = notes,
                    fontSize = 11.sp,
                    color = SlateTextSecondary,
                    modifier = Modifier.weight(1f)
                )

                if (status == "pending") {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { /* approve */ },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text(if (isHindi) "स्वीकार करें" else "Approve", fontSize = 10.sp)
                        }
                        OutlinedButton(
                            onClick = { /* reject */ },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text(if (isHindi) "अस्वीकार" else "Reject", fontSize = 10.sp, color = RoseExpense)
                        }
                    }
                } else {
                    Surface(
                        color = EmeraldLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (isHindi) "स्वीकृत" else "Approved",
                            color = EmeraldAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
