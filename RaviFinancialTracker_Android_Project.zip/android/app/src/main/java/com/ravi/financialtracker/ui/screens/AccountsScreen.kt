package com.ravi.financialtracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravi.financialtracker.ui.theme.*

@Composable
fun AccountsScreen(isHindi: Boolean) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Bank Accounts, 1: Credit Cards, 2: Loans

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp)
    ) {
        Text(
            text = if (isHindi) "खाते, कार्ड एवं ऋण (Accounts & Liabilities)" else "Accounts, Cards & Loans",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(if (isHindi) "बैंक खाते" else "Bank Accounts") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(if (isHindi) "क्रेडिट कार्ड" else "Credit Cards") }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text(if (isHindi) "ऋण (Loans)" else "Loans & EMIs") }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (selectedTab) {
                0 -> {
                    // Bank Accounts
                    item {
                        BankCard(
                            bankName = "HDFC Bank",
                            accType = if (isHindi) "वेतन खाता (Salary A/c)" else "Salary Account",
                            last4 = "4892",
                            balance = "₹1,42,500"
                        )
                    }
                    item {
                        BankCard(
                            bankName = "ICICI Bank",
                            accType = if (isHindi) "बचत खाता (Savings A/c)" else "Savings Account",
                            last4 = "7103",
                            balance = "₹85,200"
                        )
                    }
                    item {
                        BankCard(
                            bankName = "State Bank of India",
                            accType = if (isHindi) "बचत खाता (Savings A/c)" else "Savings Account",
                            last4 = "9921",
                            balance = "₹32,400"
                        )
                    }
                }
                1 -> {
                    // Credit Cards
                    item {
                        CreditCardItem(
                            cardName = "HDFC Regalia Gold",
                            last4 = "3819",
                            outstanding = "₹28,450",
                            limit = "₹4,00,000",
                            dueDate = "05 Nov 2026",
                            minDue = "₹1,420"
                        )
                    }
                    item {
                        CreditCardItem(
                            cardName = "Amazon Pay ICICI",
                            last4 = "9044",
                            outstanding = "₹12,890",
                            limit = "₹2,50,000",
                            dueDate = "10 Nov 2026",
                            minDue = "₹650"
                        )
                    }
                }
                2 -> {
                    // Loans & EMIs
                    item {
                        LoanItem(
                            lender = "State Bank of India",
                            loanType = if (isHindi) "गृह ऋण (Home Loan)" else "Home Loan",
                            principal = "₹45,00,000",
                            outstanding = "₹38,20,000",
                            emi = "₹38,500",
                            rate = "8.5%",
                            nextDue = "10 Nov 2026"
                        )
                    }
                    item {
                        LoanItem(
                            lender = "HDFC Bank",
                            loanType = if (isHindi) "कार ऋण (Auto Loan)" else "Auto Loan",
                            principal = "₹8,00,000",
                            outstanding = "₹2,90,000",
                            emi = "₹16,400",
                            rate = "8.9%",
                            nextDue = "05 Nov 2026"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BankCard(bankName: String, accType: String, last4: String, balance: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = bankName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = "$accType ••$last4", fontSize = 11.sp, color = SlateTextSecondary)
            }
            Text(text = balance, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = NavyPrimary)
        }
    }
}

@Composable
fun CreditCardItem(cardName: String, last4: String, outstanding: String, limit: String, dueDate: String, minDue: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = cardName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = outstanding, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = RoseExpense)
            }
            Text(text = "Card ending ••$last4", fontSize = 11.sp, color = SlateTextSecondary)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Limit: $limit", fontSize = 11.sp, color = SlateTextSecondary)
                Text(text = "Due: $dueDate (Min: $minDue)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = AmberWarning)
            }
        }
    }
}

@Composable
fun LoanItem(lender: String, loanType: String, principal: String, outstanding: String, emi: String, rate: String, nextDue: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = lender, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = "$loanType • Interest: $rate", fontSize = 11.sp, color = SlateTextSecondary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = emi, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AmberWarning)
                    Text(text = "Monthly EMI", fontSize = 10.sp, color = SlateTextSecondary)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = "Remaining: $outstanding", fontSize = 11.sp, color = SlateTextSecondary)
                Text(text = "Next Due: $nextDue", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
