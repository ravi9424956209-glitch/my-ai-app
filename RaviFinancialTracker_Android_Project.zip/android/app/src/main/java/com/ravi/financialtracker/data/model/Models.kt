package com.ravi.financialtracker.data.model

import com.google.gson.annotations.SerializedName

data class DashboardResponse(
    @SerializedName("overview") val overview: FinancialOverview,
    @SerializedName("pendingTransactions") val pendingTransactions: List<TransactionModel>,
    @SerializedName("recentTransactions") val recentTransactions: List<TransactionModel>,
    @SerializedName("accountsSummary") val accounts: List<AccountModel>,
    @SerializedName("creditCardsSummary") val creditCards: List<CreditCardModel>,
    @SerializedName("loansSummary") val loans: List<LoanModel>,
    @SerializedName("connectedEmailAccounts") val connectedEmailAccounts: List<EmailAccountModel>
)

data class FinancialOverview(
    @SerializedName("netWorth") val netWorth: Double = 0.0,
    @SerializedName("totalBankBalance") val totalBankBalance: Double = 0.0,
    @SerializedName("totalCreditOutstanding") val totalCreditOutstanding: Double = 0.0,
    @SerializedName("totalLoanOutstanding") val totalLoanOutstanding: Double = 0.0,
    @SerializedName("totalConfirmedIncome") val totalConfirmedIncome: Double = 0.0,
    @SerializedName("totalConfirmedExpense") val totalConfirmedExpense: Double = 0.0,
    @SerializedName("netSavings") val netSavings: Double = 0.0,
    @SerializedName("savingsRatePercent") val savingsRatePercent: Double = 0.0,
    @SerializedName("pendingCount") val pendingCount: Int = 0,
    @SerializedName("pendingAmount") val pendingAmount: Double = 0.0
)

data class TransactionModel(
    @SerializedName("id") val id: String,
    @SerializedName("amount") val amount: Double,
    @SerializedName("currency") val currency: String = "INR",
    @SerializedName("type") val type: String, // "debit" | "credit"
    @SerializedName("transactionNature") val transactionNature: String = "expense",
    @SerializedName("status") val status: String, // "pending" | "approved" | "rejected"
    @SerializedName("date") val date: String,
    @SerializedName("time") val time: String = "12:00:00",
    @SerializedName("merchant") val merchant: String,
    @SerializedName("bankName") val bankName: String,
    @SerializedName("accountLast4") val accountLast4: String = "",
    @SerializedName("referenceNumber") val referenceNumber: String = "",
    @SerializedName("paymentMethod") val paymentMethod: String = "UPI",
    @SerializedName("category") val category: String = "Other",
    @SerializedName("notes") val notes: String = "",
    @SerializedName("isTransfer") val isTransfer: Boolean = false,
    @SerializedName("needsReview") val needsReview: Boolean = false,
    @SerializedName("confidenceScore") val confidenceScore: Double = 0.95
)

data class AccountModel(
    @SerializedName("id") val id: String,
    @SerializedName("bankName") val bankName: String,
    @SerializedName("accountType") val accountType: String,
    @SerializedName("accountLast4") val accountLast4: String,
    @SerializedName("balance") val balance: Double,
    @SerializedName("currency") val currency: String = "INR"
)

data class CreditCardModel(
    @SerializedName("id") val id: String,
    @SerializedName("issuer") val issuer: String,
    @SerializedName("cardName") val cardName: String,
    @SerializedName("cardLast4") val cardLast4: String,
    @SerializedName("creditLimit") val creditLimit: Double,
    @SerializedName("currentOutstanding") val currentOutstanding: Double,
    @SerializedName("billingCycleDay") val billingCycleDay: Int,
    @SerializedName("dueDate") val dueDate: String,
    @SerializedName("lastPaymentAmount") val lastPaymentAmount: Double = 0.0
)

data class LoanModel(
    @SerializedName("id") val id: String,
    @SerializedName("lender") val lender: String,
    @SerializedName("loanType") val loanType: String,
    @SerializedName("principalAmount") val principalAmount: Double,
    @SerializedName("outstandingAmount") val outstandingAmount: Double,
    @SerializedName("emiAmount") val emiAmount: Double,
    @SerializedName("tenureMonths") val tenureMonths: Int,
    @SerializedName("nextDueDate") val nextDueDate: String,
    @SerializedName("interestRate") val interestRate: Double
)

data class EmailAccountModel(
    @SerializedName("id") val id: String,
    @SerializedName("provider") val provider: String,
    @SerializedName("emailAddress") val emailAddress: String,
    @SerializedName("displayName") val displayName: String,
    @SerializedName("status") val status: String,
    @SerializedName("lastSyncedAt") val lastSyncedAt: String? = null
)

data class TransactionsResponse(
    @SerializedName("total") val total: Int,
    @SerializedName("transactions") val transactions: List<TransactionModel>
)

data class ActionResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String? = null
)
