package com.ravi.financialtracker.data.api

import com.ravi.financialtracker.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface RaviFinancialApi {
    @GET("api/dashboard")
    suspend fun getDashboard(
        @Header("Authorization") token: String
    ): Response<DashboardResponse>

    @GET("api/transactions")
    suspend fun getTransactions(
        @Header("Authorization") token: String,
        @Query("status") status: String? = null,
        @Query("category") category: String? = null,
        @Query("startDate") startDate: String? = null,
        @Query("endDate") endDate: String? = null,
        @Query("search") search: String? = null
    ): Response<TransactionsResponse>

    @POST("api/transactions/{id}/approve")
    suspend fun approveTransaction(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ): Response<ActionResponse>

    @POST("api/transactions/{id}/reject")
    suspend fun rejectTransaction(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ): Response<ActionResponse>

    @PATCH("api/transactions/{id}")
    suspend fun updateTransaction(
        @Header("Authorization") token: String,
        @Path("id") id: String,
        @Body updates: Map<String, Any>
    ): Response<ActionResponse>

    @POST("api/transactions/import")
    suspend fun importTransactions(
        @Header("Authorization") token: String,
        @Body payload: Map<String, Any>
    ): Response<ActionResponse>

    @POST("api/email/sync")
    suspend fun syncEmails(
        @Header("Authorization") token: String,
        @Body payload: Map<String, Any>
    ): Response<ActionResponse>

    @GET("api/reports")
    suspend fun getReports(
        @Header("Authorization") token: String,
        @Query("startDate") startDate: String? = null,
        @Query("endDate") endDate: String? = null
    ): Response<Map<String, Any>>
}
