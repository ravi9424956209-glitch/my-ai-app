package com.ravi.financialtracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravi.financialtracker.ui.theme.*

@Composable
fun ReportsScreen(isHindi: Boolean) {
    var selectedRange by remember { mutableStateOf("This Month") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (isHindi) "वित्तीय रिपोर्ट एवं विश्लेषण" else "Financial Reports & Analytics",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
            Text(
                text = if (isHindi) "समय क्षेत्र: Asia/Kolkata • केवल स्वीकृत लेन-देन शामिल" else "Timezone: Asia/Kolkata • Approved transactions only",
                fontSize = 11.sp,
                color = SlateTextSecondary
            )
        }

        // Filter Dropdown / Range selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isHindi) "अवधि: इस महीने (This Month)" else "Range: This Month",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = NavyPrimary
                )
                Button(
                    onClick = { /* Export PDF */ },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isHindi) "पीडीएफ निर्यात" else "Export PDF", fontSize = 11.sp)
                }
            }
        }

        // Summary KPI Box
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(if (isHindi) "नकद प्रवाह सारांश" else "Cash Flow Summary", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (isHindi) "कुल स्वीकृत आय:" else "Total Inflow:", fontSize = 12.sp, color = SlateTextSecondary)
                        Text("₹1,85,000", fontWeight = FontWeight.Bold, color = EmeraldAccent, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (isHindi) "कुल स्वीकृत खर्च:" else "Total Outflow:", fontSize = 12.sp, color = SlateTextSecondary)
                        Text("₹43,939", fontWeight = FontWeight.Bold, color = RoseExpense, fontSize = 13.sp)
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (isHindi) "शुद्ध बचत (Net Savings):" else "Net Savings:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("₹1,41,061", fontWeight = FontWeight.ExtraBold, color = NavyPrimary, fontSize = 14.sp)
                    }
                }
            }
        }

        // Category breakdown
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(if (isHindi) "श्रेणी-वार खर्च (Category Breakdown)" else "Category-wise Spending", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    CategoryRow("Loan & EMI", "₹38,500", "87.6%")
                    CategoryRow("Shopping", "₹4,599", "10.4%")
                    CategoryRow("Food & Dining", "₹840", "1.9%")
                }
            }
        }
    }
}

@Composable
fun CategoryRow(category: String, amount: String, percentage: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(category, fontSize = 12.sp, color = NavyPrimary)
        Text("$amount ($percentage)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SlateTextSecondary)
    }
}
