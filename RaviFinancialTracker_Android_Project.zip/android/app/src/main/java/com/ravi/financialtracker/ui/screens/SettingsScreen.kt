package com.ravi.financialtracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravi.financialtracker.ui.theme.*

@Composable
fun SettingsScreen(
    isHindi: Boolean,
    onLanguageChange: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = if (isHindi) "सेटिंग्स एवं प्राथमिकताएं" else "Settings & Preferences",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary
            )
        }

        // Language toggle
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(if (isHindi) "भाषा (Language)" else "App Language", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(if (isHindi) "वर्तमान: हिन्दी (Hindi)" else "Current: English", fontSize = 11.sp, color = SlateTextSecondary)
                    }
                    Button(
                        onClick = { onLanguageChange(!isHindi) },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                    ) {
                        Text(if (isHindi) "English" else "हिन्दी")
                    }
                }
            }
        }

        // Currency & Timezone
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (isHindi) "मुद्रा (Currency)" else "Default Currency", fontSize = 13.sp)
                        Text("INR (₹)", fontWeight = FontWeight.Bold, color = NavyPrimary)
                    }
                    Divider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (isHindi) "समय क्षेत्र (Timezone)" else "Timezone", fontSize = 13.sp)
                        Text("Asia/Kolkata", fontWeight = FontWeight.Bold, color = NavyPrimary)
                    }
                }
            }
        }

        // Connected Email Accounts
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isHindi) "जुड़े हुए ईमेल खाते (Email Connections)" else "Connected Email Accounts", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("ravi9424956209@gmail.com (Google Workspace)", fontSize = 12.sp, color = EmeraldAccent)
                    Text("Read-only financial alert scanning active.", fontSize = 11.sp, color = SlateTextSecondary)
                }
            }
        }

        // Data Management & Privacy
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (isHindi) "गोपनीयता व डेटा नियंत्रण" else "Privacy & Data Controls", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        if (isHindi)
                            "• पासवर्ड कभी फोन या सर्वर पर सादा टेक्स्ट में स्टोर नहीं होते।\n• एसएमएस केवल यूजर द्वारा शेयरशीट से साझा करने पर ही पढ़ा जाता है।\n• केवल स्वीकृत लेन-देन ही वित्तीय रिपोर्ट में गिने जाते हैं।"
                        else
                            "• Passwords never stored in plain text.\n• SMS only read when shared intentionally by user via Sharesheet.\n• Unapproved transactions never enter confirmed balances.",
                        fontSize = 11.sp,
                        color = SlateTextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
