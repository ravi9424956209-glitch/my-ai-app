package com.ravi.financialtracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ravi.financialtracker.data.model.*
import com.ravi.financialtracker.ui.theme.*

@Composable
fun HomeScreen(
    isHindi: Boolean,
    onNavigateToTransactions: () -> Unit
) {
    // In-app state with Hindi / English localization
    var selectedDateFilter by remember { mutableStateOf("This Month") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isHindi) "रवि फाइनेंशियल ट्रैकर" else "Ravi Financial Tracker",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = if (isHindi) "एशिया/कोलकाता समय क्षेत्र • सुरक्षित वित्तीय खाता" else "Asia/Kolkata • Secure Financial Ledger",
                        fontSize = 12.sp,
                        color = SlateTextSecondary
                    )
                }
                IconButton(onClick = { /* trigger sync */ }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Sync", tint = EmeraldAccent)
                }
            }
        }

        // Net Worth Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isHindi) "कुल नेट वर्थ (Net Worth)" else "Total Net Worth",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    )
                    Text(
                        text = "₹1,85,250",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(if (isHindi) "बैंक बैलेंस" else "Bank Balance", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Text("₹2,60,100", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Column {
                            Text(if (isHindi) "कुल देनदारी (Liabilities)" else "Total Liabilities", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Text("₹74,850", color = RoseExpense, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // Income, Expenses & Net Savings Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = EmeraldAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isHindi) "कुल आय" else "Total Income", fontSize = 11.sp, color = SlateTextSecondary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("₹1,85,000", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = EmeraldAccent)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = RoseExpense, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isHindi) "कुल खर्च" else "Total Expense", fontSize = 11.sp, color = SlateTextSecondary)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("₹43,939", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = RoseExpense)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(if (isHindi) "बचत (दर)" else "Net Savings", fontSize = 11.sp, color = SlateTextSecondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("₹1,41,061", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NavyPrimary)
                        Text("76.2%", fontSize = 10.sp, color = EmeraldAccent, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Pending Approval Banner
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "समीक्षा के लिए लंबित लेनदेन (2)" else "Pending Approvals (2)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF92400E)
                        )
                        Text(
                            text = if (isHindi) "एआई ईमेल अलर्ट • राशि: ₹3,070" else "AI Email Alerts • Total: ₹3,070",
                            fontSize = 11.sp,
                            color = Color(0xFFB45309)
                        )
                    }
                    Button(
                        onClick = onNavigateToTransactions,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB45309)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(if (isHindi) "समीक्षा करें" else "Review", fontSize = 11.sp)
                    }
                }
            }
        }

        // Upcoming EMI & Outstanding
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(if (isHindi) "आगामी ईएमआई (SBI)" else "Upcoming EMI (SBI)", fontSize = 11.sp, color = SlateTextSecondary)
                        Text("₹38,500", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = AmberWarning)
                        Text(if (isHindi) "देय: 10 नवंबर" else "Due: 10 Nov", fontSize = 10.sp, color = SlateTextSecondary)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(if (isHindi) "क्रेडिट कार्ड बकाया" else "Credit Card Due", fontSize = 11.sp, color = SlateTextSecondary)
                        Text("₹41,340", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = RoseExpense)
                        Text(if (isHindi) "2 सक्रिय कार्ड" else "2 Active Cards", fontSize = 10.sp, color = SlateTextSecondary)
                    }
                }
            }
        }
    }
}
