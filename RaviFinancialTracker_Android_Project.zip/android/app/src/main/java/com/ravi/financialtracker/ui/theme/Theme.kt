package com.ravi.financialtracker.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0F172A)
val NavySurface = Color(0xFF1E293B)
val EmeraldAccent = Color(0xFF10B981)
val EmeraldLight = Color(0xFFD1FAE5)
val RoseExpense = Color(0xFFF43F5E)
val AmberWarning = Color(0xFFF59E0B)
val WhiteBackground = Color(0xFFFFFFFF)
val SlateTextSecondary = Color(0xFF64748B)

private val LightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    secondary = EmeraldAccent,
    onSecondary = Color.White,
    background = WhiteBackground,
    surface = WhiteBackground,
    onSurface = NavyPrimary,
    error = RoseExpense
)

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldAccent,
    onPrimary = NavyPrimary,
    secondary = EmeraldAccent,
    background = NavyPrimary,
    surface = NavySurface,
    onSurface = Color.White,
    error = RoseExpense
)

@Composable
fun RaviFinanceTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
